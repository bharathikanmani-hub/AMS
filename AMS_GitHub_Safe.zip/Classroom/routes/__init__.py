"""AttendAI application routes package."""
